"""
strategy.py
-----------
Core indicator + rule engine for the NSE/BSE Swing Trading Bot.
No trading advice is guaranteed to be profitable — this is a
rule-based decision-support tool, not a guarantee of returns.
"""

import numpy as np
import pandas as pd


# ---------------------------------------------------------------------
# INDICATORS
# ---------------------------------------------------------------------

def ema(series: pd.Series, span: int) -> pd.Series:
    return series.ewm(span=span, adjust=False).mean()


def rsi(series: pd.Series, period: int = 14) -> pd.Series:
    delta = series.diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    avg_gain = gain.ewm(alpha=1 / period, adjust=False).mean()
    avg_loss = loss.ewm(alpha=1 / period, adjust=False).mean()
    rs = avg_gain / avg_loss.replace(0, np.nan)
    out = 100 - (100 / (1 + rs))
    return out.fillna(50)


def macd(series: pd.Series, fast: int = 12, slow: int = 26, signal: int = 9):
    macd_line = ema(series, fast) - ema(series, slow)
    signal_line = ema(macd_line, signal)
    hist = macd_line - signal_line
    return macd_line, signal_line, hist


def atr(df: pd.DataFrame, period: int = 14) -> pd.Series:
    high, low, close = df["High"], df["Low"], df["Close"]
    prev_close = close.shift(1)
    tr = pd.concat(
        [high - low, (high - prev_close).abs(), (low - prev_close).abs()],
        axis=1,
    ).max(axis=1)
    return tr.ewm(alpha=1 / period, adjust=False).mean()


def add_indicators(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["EMA20"] = ema(df["Close"], 20)
    df["EMA50"] = ema(df["Close"], 50)
    df["EMA200"] = ema(df["Close"], 200)
    df["RSI14"] = rsi(df["Close"], 14)
    df["MACD"], df["MACD_SIGNAL"], df["MACD_HIST"] = macd(df["Close"])
    df["ATR14"] = atr(df, 14)
    df["VOL_AVG20"] = df["Volume"].rolling(20).mean()
    df["HIGH20"] = df["High"].rolling(20).max()
    df["LOW20"] = df["Low"].rolling(20).min()
    df["SWING_LOW10"] = df["Low"].rolling(10).min()
    return df


# ---------------------------------------------------------------------
# SIGNAL ENGINE
# ---------------------------------------------------------------------

def generate_signal(df: pd.DataFrame, min_reward_risk: float = 2.0) -> dict:
    """
    Looks at the most recent completed candle(s) and applies the
    swing-trading rule set. Returns a dict describing the decision.
    """
    df = add_indicators(df)
    if len(df) < 210:
        return {"signal": "NOT_ENOUGH_DATA", "reasons": ["Need >= 210 daily candles for EMA200"]}

    last = df.iloc[-1]
    prev = df.iloc[-2]
    prev3 = df.iloc[-4:-1]

    reasons = []

    # ---- Trend filter ----
    uptrend = last["Close"] > last["EMA50"] > last["EMA200"]
    downtrend = last["Close"] < last["EMA50"] < last["EMA200"]

    # ---- Momentum: RSI ----
    rsi_val = last["RSI14"]
    rsi_ok_buy = 45 <= rsi_val <= 65 or (prev["RSI14"] < 50 <= rsi_val)
    rsi_overbought_turning_down = rsi_val > 70 and last["RSI14"] < prev["RSI14"]

    # ---- MACD crossover (within last 3 candles) ----
    bullish_cross = any(
        (df["MACD"].shift(1) < df["MACD_SIGNAL"].shift(1))
        & (df["MACD"] > df["MACD_SIGNAL"])
    ).__and__(True)
    recent_bullish_cross = (
        (df["MACD"].iloc[-4:-1].shift(1) < df["MACD_SIGNAL"].iloc[-4:-1].shift(1))
        & (df["MACD"].iloc[-4:-1] > df["MACD_SIGNAL"].iloc[-4:-1])
    ).any()
    bearish_cross_now = (prev["MACD"] > prev["MACD_SIGNAL"]) and (last["MACD"] < last["MACD_SIGNAL"])

    # ---- Volume confirmation ----
    vol_confirm = last["Volume"] > 1.2 * last["VOL_AVG20"] if pd.notna(last["VOL_AVG20"]) else False

    # ---- Price action ----
    breakout = last["Close"] >= last["HIGH20"] * 0.999  # at/above 20-day high
    ema20_bounce = (prev["Low"] <= prev["EMA20"] * 1.01) and (last["Close"] > last["EMA20"])
    close_below_ema20 = last["Close"] < last["EMA20"]

    # ---- Count BUY confirmations ----
    confirmations = []
    if rsi_ok_buy:
        confirmations.append("RSI in bullish zone (45-65) or just crossed above 50")
    if recent_bullish_cross:
        confirmations.append("MACD bullish crossover in last 3 candles")
    if vol_confirm:
        confirmations.append("Volume > 1.2x 20-day average")
    if breakout or ema20_bounce:
        confirmations.append("Breakout above 20-day high" if breakout else "Bounce off EMA20 support")

    signal = "HOLD"
    entry = stop_loss = target = reward_risk = None

    if uptrend and len(confirmations) >= 2:
        entry = round(float(last["Close"]), 2)
        swing_low = float(last["SWING_LOW10"])
        atr_sl = entry - 1.5 * float(last["ATR14"])
        stop_loss = round(max(swing_low, atr_sl), 2)  # tighter of the two (higher value)
        risk = entry - stop_loss
        if risk > 0:
            target = round(entry + min_reward_risk * risk, 2)
            reward_risk = round((target - entry) / risk, 2)
            if reward_risk >= min_reward_risk:
                signal = "BUY"
                reasons = confirmations + [
                    f"Trend: Close > EMA50 > EMA200 (uptrend confirmed)",
                    f"Reward:Risk = {reward_risk}:1 (meets {min_reward_risk}:1 minimum)",
                ]
            else:
                signal = "HOLD"
                reasons = [f"Setup present but Reward:Risk only {reward_risk}:1 (< {min_reward_risk}:1 min)"]
        else:
            reasons = ["Setup present but stop-loss calc invalid (risk <= 0)"]

    elif downtrend:
        signal = "AVOID"
        reasons = ["Downtrend: Close < EMA50 < EMA200 — no fresh long entries"]

    elif rsi_overbought_turning_down or bearish_cross_now or close_below_ema20:
        signal = "SELL"
        trigger = []
        if rsi_overbought_turning_down:
            trigger.append("RSI > 70 and turning down (overbought exit)")
        if bearish_cross_now:
            trigger.append("MACD bearish crossover")
        if close_below_ema20:
            trigger.append("Close broke below EMA20")
        reasons = trigger

    else:
        reasons = confirmations if confirmations else [
            "No strong trend or trigger present — sit on the sidelines"
        ]

    return {
        "signal": signal,
        "close": round(float(last["Close"]), 2),
        "date": str(df.index[-1].date()) if hasattr(df.index[-1], "date") else str(df.index[-1]),
        "rsi14": round(float(rsi_val), 1),
        "ema20": round(float(last["EMA20"]), 2),
        "ema50": round(float(last["EMA50"]), 2),
        "ema200": round(float(last["EMA200"]), 2),
        "entry": entry,
        "stop_loss": stop_loss,
        "target": target,
        "reward_risk": reward_risk,
        "reasons": reasons,
    }


def position_size(capital: float, risk_pct: float, entry: float, stop_loss: float) -> int:
    """Number of shares to buy given account risk rules."""
    if entry is None or stop_loss is None or entry <= stop_loss:
        return 0
    risk_amount = capital * (risk_pct / 100.0)
    per_share_risk = entry - stop_loss
    return int(risk_amount // per_share_risk)
