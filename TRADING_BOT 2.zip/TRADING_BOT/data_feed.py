"""
data_feed.py
------------
Fetches OHLCV data for NSE/BSE stocks using Yahoo Finance (yfinance).

NSE tickers: append ".NS"   e.g. RELIANCE.NS, TCS.NS, INFY.NS
BSE tickers: append ".BO"   e.g. RELIANCE.BO, 500325.BO

You need an active internet connection on the machine running this
script — Yahoo Finance is a free, no-API-key data source but is not
officially supported for commercial use; for production use consider
a licensed feed (NSE/BSE data vendors, Zerodha Kite Connect, etc).
"""

import time
import pandas as pd
import yfinance as yf


def normalize_ticker(ticker: str, exchange: str = "NSE") -> str:
    ticker = ticker.strip().upper()
    if ticker.endswith(".NS") or ticker.endswith(".BO"):
        return ticker
    suffix = ".NS" if exchange.upper() == "NSE" else ".BO"
    return ticker + suffix


def fetch_daily(ticker: str, exchange: str = "NSE", period: str = "2y") -> pd.DataFrame:
    """
    Fetch daily candles. period examples: '6mo','1y','2y','5y'
    Returns a DataFrame with columns Open, High, Low, Close, Volume.
    """
    symbol = normalize_ticker(ticker, exchange)
    df = yf.download(symbol, period=period, interval="1d", progress=False, auto_adjust=True)
    if df.empty:
        raise ValueError(f"No data returned for {symbol}. Check the ticker symbol.")
    # yfinance sometimes returns MultiIndex columns for single tickers
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = df.columns.get_level_values(0)
    return df[["Open", "High", "Low", "Close", "Volume"]].dropna()


def fetch_live_quote(ticker: str, exchange: str = "NSE") -> dict:
    """Fetch the latest available price snapshot (delayed ~15 min on free feed)."""
    symbol = normalize_ticker(ticker, exchange)
    t = yf.Ticker(symbol)
    info = t.fast_info
    return {
        "symbol": symbol,
        "last_price": getattr(info, "last_price", None),
        "day_high": getattr(info, "day_high", None),
        "day_low": getattr(info, "day_low", None),
        "prev_close": getattr(info, "previous_close", None),
        "volume": getattr(info, "last_volume", None),
    }


def fetch_watchlist(tickers, exchange: str = "NSE", period: str = "2y", pause: float = 0.3):
    """Fetch daily data for a list of tickers, yielding (ticker, df) pairs."""
    for tk in tickers:
        try:
            df = fetch_daily(tk, exchange, period)
            yield tk, df
        except Exception as e:
            yield tk, e
        time.sleep(pause)  # be polite to the free endpoint
