"""
nse_data.py
-----------
Fetches LIVE quotes directly from NSE India's own website API
(nseindia.com) as an alternative/backup to Yahoo Finance.

Why this works where a browser fetch wouldn't:
------------------------------------------------
NSE's API blocks requests that don't look like they came from a real
browser session (no CORS headers for arbitrary origins, and it rejects
requests without the right headers/cookies). This module makes the
request the way a browser would -- with real browser headers, and by
first "warming up" a session on the NSE homepage to obtain cookies --
which works fine from a Python script (server-to-server), even though
the exact same request would fail if made directly from a webpage in
someone's browser via JavaScript fetch().

Notes:
- This is India's official exchange, so if it's reachable at all it is
  about as "live" as free data gets (a few seconds of exchange-side
  delay, not Yahoo's ~15-20 min delay).
- NSE occasionally changes its API/rate-limits aggressively. Treat this
  as a secondary source: keep Yahoo Finance for historical candles
  (used for the indicators/rules) and use this for the live ticker
  price. If NSE blocks a request, fall back to Yahoo automatically.
- Only use this for occasional polling (a few requests per minute),
  not tight loops -- aggressive polling is likely to get blocked.
"""

import requests

BASE_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    ),
    "Accept": "application/json, text/plain, */*",
    "Accept-Language": "en-US,en;q=0.9",
    "Referer": "https://www.nseindia.com/",
}


def _get_session() -> requests.Session:
    """Warm up a session against the NSE homepage to obtain required cookies."""
    session = requests.Session()
    session.headers.update(BASE_HEADERS)
    # A plain GET to the homepage sets the cookies the API needs.
    session.get("https://www.nseindia.com", timeout=8)
    return session


def get_live_quote(symbol: str) -> dict:
    """
    Fetch a live quote for an NSE equity symbol (no .NS suffix -- just
    the base symbol, e.g. 'RELIANCE', 'TCS', 'INFY').

    Returns a dict with lastPrice, open, dayHigh, dayLow, previousClose,
    change, pChange, and totalTradedVolume.

    Raises requests.HTTPError / requests.RequestException on failure --
    callers should catch this and fall back to another source (e.g. Yahoo).
    """
    symbol = symbol.strip().upper()
    session = _get_session()
    url = f"https://www.nseindia.com/api/quote-equity?symbol={symbol}"
    resp = session.get(url, timeout=8)
    resp.raise_for_status()
    data = resp.json()

    price_info = data.get("priceInfo", {})
    return {
        "symbol": symbol,
        "last_price": price_info.get("lastPrice"),
        "open": price_info.get("open"),
        "day_high": price_info.get("intraDayHighLow", {}).get("max"),
        "day_low": price_info.get("intraDayHighLow", {}).get("min"),
        "previous_close": price_info.get("previousClose"),
        "change": price_info.get("change"),
        "pct_change": price_info.get("pChange"),
        "source": "NSE India (official)",
    }


def get_live_quote_with_fallback(symbol: str, yahoo_fallback_fn=None) -> dict:
    """
    Try NSE's own API first (more "live", official source); if it fails
    for any reason (blocked, timeout, symbol not found), fall back to
    the given Yahoo Finance function so the bot keeps working either way.

    yahoo_fallback_fn: a callable like data_feed.fetch_live_quote(symbol, exchange)
    """
    try:
        return get_live_quote(symbol)
    except Exception as nse_err:
        if yahoo_fallback_fn is None:
            raise
        result = yahoo_fallback_fn(symbol, "NSE")
        result["source"] = "Yahoo Finance (fallback -- NSE unavailable: %s)" % nse_err
        return result


if __name__ == "__main__":
    # Quick manual test when run directly on your own machine:
    #   python nse_data.py RELIANCE
    import sys
    sym = sys.argv[1] if len(sys.argv) > 1 else "RELIANCE"
    print(get_live_quote(sym))
